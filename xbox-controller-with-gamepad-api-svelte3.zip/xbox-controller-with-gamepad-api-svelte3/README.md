# XBOX Controller (with GamePad API & Svelte3)

A Pen created on CodePen.io. Original URL: [https://codepen.io/simeydotme/pen/rNepONX](https://codepen.io/simeydotme/pen/rNepONX).

A visual UI for xbox controller which updates when a controller is connected to the device and the buttons are pressed.

Built with Svelte